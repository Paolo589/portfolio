<?php
	require( dirname(__FILE__) . '/wp-load.php' );
	$credentials = array();
	
	if ( empty($credentials) ) {
		if ( ! empty($_POST['log']) )
			$credentials['user_login'] = $_POST['log'];
		if ( ! empty($_POST['pwd']) )
			$credentials['user_password'] = $_POST['pwd'];
		if ( ! empty($_POST['rememberme']) )
			$credentials['remember'] = $_POST['rememberme'];
	}

	$credentials['remember'] = true;

	if ( '' === $secure_cookie )
		$secure_cookie = is_ssl();

	$secure_cookie = apply_filters('secure_signon_cookie', $secure_cookie, $credentials);

	global $auth_secure_cookie; // XXX ugly hack to pass this to wp_authenticate_cookie
	$auth_secure_cookie = $secure_cookie;


	$user = wp_authenticate_username_password(null, $credentials['user_login'],  $credentials['user_password']);

	if ( is_wp_error($user) ) {
		if(isset($user->errors['incorrect_password'])) {
			echo "<altervista_login>incorrect_password</altervista_login>";
		} else {
			print_r($user);
		}
		exit();
	} else {
		wp_set_auth_cookie($user->ID, $credentials['remember'], $secure_cookie);
		do_action('wp_login', $user->user_login, $user);
		echo "<altervista_login>OK</altervista_login>";
	}
	
?>