<?php
$url = $_GET['url'];
$cookies = $_GET['cookie'];
$iframe = $_GET['iframe'];
$lang = $_GET['lang'];

if ($iframe) {
	header("P3P: CP='CAO PSA OUR'");
}

foreach ($cookies as $cookie) header("Set-Cookie: $cookie\n", false);

if (!$iframe) {
	header("Location: $url");
	exit;
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>Basic Admin Opener</title>
<style type="text/css">

* {
	margin: 0;
	padding: 0;
	border: 0;
}

p {
	font: bold 12px sans-serif;
	padding: 3px;
	line-height: 16px;
}

a {
	text-decoration: none;
	color: #4C5CBD;
}

a:hover {
	color: #F8971D;
}

iframe {
	width: 99%;
	height: 570px;
	border:1px inset black
}

img {
	margin-right: 10px;
	cursor: pointer;
	vertical-align: middle;
}

</style>
</head>
<body>
<p>
	<a onclick="this.href=frames['myiframe'].location.href;return true" target="_blank" href="#">
		<img src="http://im.altervista.org/cp/icon/window_full.gif" alt="fullscreen" border="0" />
<?php
	if($lang == 'it') {
		print "Clicca qui per aprire la pagina a tutto schermo";
	} else {
		print "Click to activate full screen mode";
	}
?>
	</a>
</p>
<div style="text-align:center">
	<iframe id="myiframe" name="myiframe" src="<?=$url?>"></iframe>
</div><body></html>